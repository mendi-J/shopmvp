/**
 * Canonical Event Registry (EVT-STAB-301).
 *
 * THE single source of truth for every event name TrackLens itself emits or
 * recognizes. Before this existed, at least four independently-maintained
 * mapping tables encoded overlapping-but-different beliefs about canonical
 * event names — and they drifted (the ingest-time map was missing $identify,
 * so every real identify() call was stored as eventType 'custom'; the
 * Coverage Score checked names like 'api_request' that no shipping SDK has
 * ever sent). All of those consumers now derive from this registry:
 *
 *   - apps/api ingest eventType normalization
 *   - apps/api coverage.service capability detection
 *   - apps/api intent.service SDK-name normalization
 *   - apps/customer-portal display labels
 *
 * Deliberately a small amount of pure, dependency-free runtime data inside
 * the otherwise types-only package — it is the only package shared by every
 * consumer, and a registry that can drift per-consumer defeats its purpose.
 *
 * Customer-defined event names are NOT in this registry and never will be:
 * unknown names pass through verbatim everywhere (original identity is
 * always preserved; there is no reserved-namespace enforcement yet — that is
 * EVT-STAB-304, a separate ticket).
 */

export type EventSource = 'auto' | 'sdk_api' | 'custom';

/**
 * Customer-facing event origin (EVT-ACT-601 / EVT-DEC-016).
 *
 * WHO/WHAT produced the record, presented so several records describing one
 * workflow read as layers rather than duplicates:
 *   BUSINESS_EVENT      — customer event explicitly classified business
 *   CUSTOMER_EVENT      — customer-emitted, not (yet) business-classified
 *   SDK_ACTIVITY        — user interaction observed by a TrackLens SDK
 *   TECHNICAL_TELEMETRY — machine-generated technical records
 * TrackLens operational events are NOT an origin here — they never enter
 * customer-visible Event scopes at all (EVT-DEC-016).
 */
export type EventOrigin =
  | 'BUSINESS_EVENT'
  | 'CUSTOMER_EVENT'
  | 'SDK_ACTIVITY'
  | 'TECHNICAL_TELEMETRY';

/** The origin split for TrackLens-emitted (registry) events. */
export type RegistryEventOrigin = Extract<EventOrigin, 'SDK_ACTIVITY' | 'TECHNICAL_TELEMETRY'>;

export interface EventDefinition {
  /** Canonical name analytics should group under. */
  canonicalName: string;
  /**
   * Every wire-level spelling that means this event, INCLUDING the canonical
   * name itself. Matching is case-insensitive.
   *
   * RULE: aliases contain ONLY spellings TrackLens SDKs actually emit (or
   * historically emitted) — never plain customer vocabulary like 'search'
   * or 'form_submission'. A customer's own event name must never be
   * rewritten or re-grouped by the registry.
   */
  aliases: readonly string[];
  /** Canonical eventType stored on the Event row. */
  eventType: string;
  /** Human-readable label for UI surfaces. */
  displayName: string;
  /** How the event originates. 'auto' = SDK plugin, 'sdk_api' = explicit SDK method. */
  source: EventSource;
  /**
   * True for machine-generated telemetry (fires without a deliberate user
   * action). Drives the analytics telemetry-scope split (EVT-STAB-502).
   */
  isTelemetry: boolean;
  /**
   * Customer-facing origin category (EVT-ACT-601): user-interaction records
   * the SDK observed vs machine-generated technical records. Independent of
   * isTelemetry (identity plumbing is TECHNICAL_TELEMETRY for presentation
   * without being scope-level telemetry).
   */
  origin: RegistryEventOrigin;
  /**
   * Explicit business-relevance determination (EVT-DEC-006). Per the
   * decision record, business-ness is NEVER inferred from !isTelemetry —
   * system interaction events ($pageview, $click), identity events and
   * telemetry are all non-business. No TrackLens-emitted event is business
   * today; the flag exists so a future registry entry (or the full
   * classification precedence: customer config → registry → project rules →
   * fallback → unknown) can flip one explicitly.
   */
  isBusinessEvent: boolean;
}

export const EVENT_REGISTRY: readonly EventDefinition[] = [
  {
    canonicalName: 'page_view',
    aliases: ['page_view', '$pageview', '$page_view', 'pageview'],
    eventType: 'page_view',
    displayName: 'Page View',
    source: 'auto',
    isTelemetry: false,
    origin: 'SDK_ACTIVITY',
    isBusinessEvent: false,
  },
  {
    canonicalName: 'screen_view',
    aliases: ['screen_view', '$screen_view'],
    eventType: 'page_view',
    displayName: 'Screen View',
    source: 'auto',
    isTelemetry: false,
    origin: 'SDK_ACTIVITY',
    isBusinessEvent: false,
  },
  {
    canonicalName: 'screen_exit',
    aliases: ['screen_exit', '$screen_exit'],
    eventType: 'page_view',
    displayName: 'Screen Exit',
    source: 'auto',
    isTelemetry: false,
    origin: 'SDK_ACTIVITY',
    isBusinessEvent: false,
  },
  {
    canonicalName: 'click',
    aliases: ['click', '$click'],
    eventType: 'click',
    displayName: 'Click',
    source: 'auto',
    isTelemetry: false,
    origin: 'SDK_ACTIVITY',
    isBusinessEvent: false,
  },
  {
    canonicalName: 'form_submit',
    aliases: ['form_submit', '$form_submit'],
    eventType: 'form_submit',
    displayName: 'Form Submission',
    source: 'auto',
    isTelemetry: false,
    origin: 'SDK_ACTIVITY',
    isBusinessEvent: false,
  },
  {
    canonicalName: 'api_call',
    aliases: ['api_call', '$api_call'],
    eventType: 'api_call',
    displayName: 'API Call',
    source: 'auto',
    isTelemetry: true,
    origin: 'TECHNICAL_TELEMETRY',
    isBusinessEvent: false,
  },
  {
    canonicalName: 'identify',
    aliases: ['identify', '$identify'],
    eventType: 'identify',
    displayName: 'User Identified',
    source: 'sdk_api',
    isTelemetry: false,
    origin: 'TECHNICAL_TELEMETRY',
    isBusinessEvent: false,
  },
  {
    canonicalName: 'search_performed',
    aliases: ['search_performed'],
    eventType: 'search',
    displayName: 'Search Performed',
    source: 'sdk_api',
    isTelemetry: false,
    origin: 'SDK_ACTIVITY',
    isBusinessEvent: false,
  },
  {
    canonicalName: 'session_start',
    aliases: ['session_start'],
    eventType: 'session',
    displayName: 'Session Started',
    source: 'auto',
    isTelemetry: true,
    origin: 'TECHNICAL_TELEMETRY',
    isBusinessEvent: false,
  },
  {
    canonicalName: 'session_end',
    aliases: ['session_end'],
    eventType: 'session',
    displayName: 'Session Ended',
    source: 'auto',
    isTelemetry: true,
    origin: 'TECHNICAL_TELEMETRY',
    isBusinessEvent: false,
  },
  {
    canonicalName: 'app_resumed',
    aliases: ['app_resumed'],
    eventType: 'app_lifecycle',
    displayName: 'App Resumed',
    source: 'auto',
    isTelemetry: true,
    origin: 'TECHNICAL_TELEMETRY',
    isBusinessEvent: false,
  },
  {
    canonicalName: 'app_paused',
    aliases: ['app_paused'],
    eventType: 'app_lifecycle',
    displayName: 'App Paused',
    source: 'auto',
    isTelemetry: true,
    origin: 'TECHNICAL_TELEMETRY',
    isBusinessEvent: false,
  },
] as const;

// Case-insensitive alias → definition index, built once at module load.
const aliasIndex: ReadonlyMap<string, EventDefinition> = (() => {
  const index = new Map<string, EventDefinition>();
  for (const def of EVENT_REGISTRY) {
    for (const alias of def.aliases) {
      index.set(alias.toLowerCase(), def);
    }
  }
  return index;
})();

/** Registry lookup by any alias, case-insensitive. Unknown names → undefined. */
export function getEventDefinition(eventName: string): EventDefinition | undefined {
  return aliasIndex.get(eventName.toLowerCase());
}

/** True when the name is one TrackLens itself emits (auto-tracked or SDK API). */
export function isRegistryEvent(eventName: string): boolean {
  return aliasIndex.has(eventName.toLowerCase());
}

/** True for machine-generated telemetry events ($api_call, lifecycle, sessions). */
export function isTelemetryEvent(eventName: string): boolean {
  return getEventDefinition(eventName)?.isTelemetry ?? false;
}

/**
 * Canonical eventType for an incoming event (replaces the ingest-time
 * normalizeEventType, whose hand-copied name map was missing $identify —
 * EVT-STAB-302).
 *
 * Resolution: a recognized event name always wins (the registry knows the
 * true type regardless of what the SDK stamped — the SDKs hardcode
 * eventType 'custom' on every track() call, including $identify); otherwise
 * a caller-supplied raw type passes through (legacy spellings mapped);
 * otherwise 'custom' for explicit track() calls, null when nothing is known.
 */
export function resolveEventType(eventName: string, rawType?: string | null): string | null {
  const def = getEventDefinition(eventName);
  if (def) return def.eventType;

  if (rawType && rawType !== 'custom') {
    const legacyTypeMap: Record<string, string> = { pageview: 'page_view', PageView: 'page_view' };
    return legacyTypeMap[rawType] ?? rawType;
  }

  return rawType ?? null;
}

/**
 * Canonical grouping name for analytics (e.g. '$pageview' and 'pageview'
 * both group as 'page_view'). Unknown names pass through verbatim —
 * customer event identity is always preserved.
 */
export function canonicalEventName(eventName: string): string {
  return getEventDefinition(eventName)?.canonicalName ?? eventName;
}

/** Display label for registry events; undefined for unknown names (UI applies its own fallback). */
export function registryDisplayName(eventName: string): string | undefined {
  return getEventDefinition(eventName)?.displayName;
}

/**
 * Analytics scope semantics (EVT-STAB-502 / decision record EVT-DEC-006,
 * corrected per the 2026-07-11 review).
 *
 * Three INDEPENDENT dimensions, never conflated:
 *   source                — who created the event (auto / customer / identity / system)
 *   business classification — should it drive business-facing analytics
 *                             (business / non-business / UNKNOWN)
 *   telemetry classification — is it technical telemetry (yes / no)
 *
 * business: ONLY events explicitly classified business — conceptually
 *   `isBusinessEvent === true` via the precedence: customer configuration →
 *   this registry → project rules → approved fallback inference → unknown.
 *   A customer calling track() makes an event customer-DEFINED, not
 *   business-CLASSIFIED: debug_modal_opened or cache_refresh_started must
 *   never appear as Business merely because the customer emitted them.
 *   Unclassified events remain Unknown and appear only under 'all'. Until
 *   EVT-STAB-305 delivers the classification service, only this registry's
 *   explicit flags exist — so the business population may be empty, which
 *   is why the DEFAULT scope is transitional (see resolveDefaultScope in
 *   the analytics service).
 * all: every customer-visible event for the project (EVT-DEC-016: NOT
 *   "everything TrackLens stores" — operational events never enter customer
 *   scopes).
 * activity: human/application interaction activity — the DEFAULT customer
 *   scope (EVT-ACT-701 / EVT-DEC-016). Everything except TECHNICAL_TELEMETRY-
 *   origin registry events, derived from registry semantics, never from
 *   hardcoded per-service name lists.
 * telemetry: only isTelemetry-flagged events ($api_call, sessions,
 *   lifecycle). Retained as an internal/power-user API scope, hidden from
 *   the primary customer UI.
 */
export type AnalyticsScope = 'all' | 'business' | 'telemetry' | 'activity';

/** Every alias of every telemetry-flagged registry event. */
export const TELEMETRY_EVENT_NAMES: readonly string[] = EVENT_REGISTRY.filter(
  (def) => def.isTelemetry
).flatMap((def) => [...def.aliases]);

/**
 * Every alias of every TECHNICAL_TELEMETRY-origin registry event — the
 * exclusion set that defines the Activity scope (EVT-DEC-016). Distinct
 * from TELEMETRY_EVENT_NAMES: origin is the customer-facing presentation
 * dimension ($identify is origin-technical without being scope-telemetry).
 */
export const TECHNICAL_TELEMETRY_EVENT_NAMES: readonly string[] = EVENT_REGISTRY.filter(
  (def) => def.origin === 'TECHNICAL_TELEMETRY'
).flatMap((def) => [...def.aliases]);

/**
 * Every alias of every EXPLICITLY business-classified registry event —
 * the positive allow-list implementing `isBusinessEvent === true`. Empty
 * today; EVT-STAB-305's classification service will extend the population
 * beyond the registry tier (customer config, project rules).
 */
export const BUSINESS_EVENT_NAMES: readonly string[] = EVENT_REGISTRY.filter(
  (def) => def.isBusinessEvent
).flatMap((def) => [...def.aliases]);

/**
 * Customer-facing origin resolution (EVT-ACT-601): registry events carry
 * their registry origin; everything else is customer vocabulary — presented
 * as BUSINESS_EVENT only when explicitly classified so (EVT-DEC-006
 * precedence), otherwise CUSTOMER_EVENT. Never inferred from name shape.
 */
export function resolveEventOrigin(
  eventName: string,
  opts?: { isBusinessEvent?: boolean | null }
): EventOrigin {
  const def = getEventDefinition(eventName);
  if (def) return def.origin;
  return opts?.isBusinessEvent === true ? 'BUSINESS_EVENT' : 'CUSTOMER_EVENT';
}
