// ============================================================
// TrackLens Shared Type Definitions
// ============================================================

// Canonical Event Registry (EVT-STAB-301) — the one deliberate exception to
// this package's types-only rule: pure, dependency-free registry data +
// lookups shared by the API and customer portal so event-name knowledge
// cannot drift per-consumer again.
export * from './event-registry';

// Central sensitive-property masking policy (EVT-STAB-401) — same
// types-only-exception rationale as the registry above.
export * from './masking-policy';

// Action Identity Contract v1 (EVT-ACT-201 / EVT-DEC-017) — normalization,
// privacy, and stability rules shared by SDK capture and ingest
// re-validation. Same types-only-exception rationale.
export * from './action-identity';
import type { ActionSource } from './action-identity';

// ---- Enums ----

export type UserRole = 'owner' | 'product_manager' | 'engineer' | 'viewer';
export type AdminRole = 'super_admin' | 'support_admin' | 'finance_admin';
export type Environment = 'development' | 'staging' | 'production';
export type Platform = 'web' | 'react_native' | 'flutter';
export type ErrorClassification = 'business' | 'validation' | 'frontend' | 'api' | 'infrastructure';
export type ErrorSeverity = 'critical' | 'error' | 'warning';
export type NotificationType =
  | 'error_spike'
  | 'new_critical_error'
  | 'crash_rate_increase'
  | 'api_failure_increase'
  | 'health_score_drop'
  | 'sdk_offline';
export type DeviceType = 'desktop' | 'tablet' | 'mobile';
export type NetworkStatus = 'online' | 'offline' | 'slow';

// ---- Auth ----

export interface AuthUser {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  isEmailVerified: boolean;
  createdAt: string;
}

export interface AdminUser {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: AdminRole;
  isActive: boolean;
  createdAt: string;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
}

export interface AuthResponse {
  user: AuthUser;
  tokens: AuthTokens;
}

// ---- Organization ----

export interface Organization {
  id: string;
  name: string;
  slug: string;
  ownerId: string;
  plan: string;
  createdAt: string;
  updatedAt: string;
}

export interface OrganizationMember {
  id: string;
  organizationId: string;
  userId: string;
  role: UserRole;
  user: Pick<AuthUser, 'id' | 'email' | 'firstName' | 'lastName'>;
  createdAt: string;
}

// ---- Project ----

export interface Project {
  id: string;
  organizationId: string;
  name: string;
  slug: string;
  platform: Platform;
  createdAt: string;
  updatedAt: string;
}

// ---- SDK Key ----

export interface SdkKey {
  id: string;
  projectId: string;
  environment: Environment;
  key: string;
  isActive: boolean;
  lastUsedAt: string | null;
  createdAt: string;
  rotatedAt: string | null;
}

// ---- Event ----

export interface EventProperties {
  [key: string]: string | number | boolean | null | undefined;
}

// V3C Wave 0A — search domain classification stored on Event rows
export type EventDomain = 'search';

export interface TrackedEvent {
  id: string;
  projectId: string;
  sessionId: string | null;
  eventName: string;
  eventType: string;
  userId: string | null;
  anonymousId: string | null;
  properties: EventProperties;
  timestamp: string;
  environment: Environment;
  url: string | null;
  path: string | null;
  referrer: string | null;
  eventDomain?: EventDomain | null; // V3C Wave 0A — populated Wave 1+; optional for backward compat
  // Action Identity Contract v1 (EVT-ACT-301) — feed rows carry the identity
  // columns plus the server-resolved origin so presentation never re-derives
  // semantics client-side. Optional: older rows/responses have none.
  actionName?: string | null;
  actionSource?: string | null;
  targetType?: string | null;
  targetId?: string | null;
  origin?: string | null;
}

// ---- Search Intelligence (V3C Wave 0A) ----

// Pre-aggregated daily search query metrics per project.
// Written by the aggregation job (Wave 1). Read by Search Intelligence APIs (Wave 2).
export interface SearchQueryAggregate {
  id: string;
  projectId: string;
  date: string; // ISO date string: YYYY-MM-DD
  environment: string;
  queryText: string;
  searchCount: number;
  sessionCount: number;
  zeroResultCount: number;
  clickCount: number;
  abandonCount: number;
  conversionCount: number;
  avgResultCount: number | null;
  avgPositionClicked: number | null;
  calculatedAt: string;
  createdAt: string;
  updatedAt: string;
}

// ---- Session ----

export interface Session {
  id: string;
  projectId: string;
  sessionId: string;
  userId: string | null;
  anonymousId: string | null;
  environment: Environment;
  platform: Platform;
  startedAt: string;
  endedAt: string | null;
  durationMs: number | null;
  pageCount: number;
  eventCount: number;
  errorCount: number;
  isActive: boolean;
  browser: string | null;
  browserVersion: string | null;
  os: string | null;
  osVersion: string | null;
  deviceType: DeviceType | null;
  deviceModel: string | null;
  screenWidth: number | null;
  screenHeight: number | null;
  country: string | null;
  city: string | null;
  appVersion: string | null;
  networkType: string | null;
}

// ---- Error ----

export interface CapturedError {
  id: string;
  projectId: string;
  sessionId: string | null;
  errorId: string;
  errorType: string | null;
  message: string;
  stackTrace: string | null;
  classification: ErrorClassification;
  severity: ErrorSeverity;
  environment: Environment;
  userId: string | null;
  anonymousId: string | null;
  url: string | null;
  path: string | null;
  browser: string | null;
  os: string | null;
  deviceType: DeviceType | null;
  appVersion: string | null;
  endpoint: string | null;
  requestDurationMs: number | null;
  responseCode: number | null;
  responseMessage: string | null;
  networkStatus: NetworkStatus | null;
  previousEvents: EventProperties[];
  previousPages: string[];
  isNew: boolean;
  isResolved: boolean;
  occurrenceCount: number;
  firstSeenAt: string;
  lastSeenAt: string;
  resolvedAt: string | null;
  replayLink: string | null;
  // TL-OBS shadow fields (populated when ENABLE_ERROR_CLASSIFICATION / ENABLE_PRODUCT_INTELLIGENCE is on)
  enhancedClassification: EnhancedClassification | null;
  enhancedSeverity: EnhancedSeverity | null;
  rootCause: string | null;
  userGoal: string | null;
  userAction: string | null;
  sdkVersion: string | null;
}

// ---- TL-OBS: Product Intelligence & Error Observability ----

export type EnhancedClassification =
  | 'user_error'
  | 'validation_error'
  | 'application_error'
  | 'api_error'
  | 'backend_error'
  | 'infrastructure_error'
  | 'authentication_error'
  | 'authorization_error'
  | 'performance_error'
  | 'third_party_error';

export type EnhancedSeverity = 'critical' | 'high' | 'medium' | 'low';

export type GoalType =
  | 'signup_blocked'
  | 'checkout_blocked'
  | 'workspace_creation_blocked'
  | 'sdk_integration_blocked'
  | 'onboarding_blocked';

export type InsightType =
  | 'top_blocked_goal'
  | 'most_failed_action'
  | 'critical_error'
  | 'error_spike'
  | 'low_funnel_conversion'
  | 'high_user_error_rate';

export type InsightImpact = 'high' | 'medium' | 'low';

export interface BlockedGoal {
  id: string;
  projectId: string;
  errorId: string;
  goalType: GoalType;
  userId: string | null;
  anonymousId: string | null;
  sessionId: string | null;
  environment: string | null;
  metadata: Record<string, unknown>;
  createdAt: string;
}

export interface FunnelStageResult {
  name: string;
  eventName: string;
  count: number;
  conversionRate: number;
  dropoffRate: number;
}

export interface FunnelResult {
  id: string;
  name: string;
  description: string | null;
  stages: FunnelStageResult[];
  overallConversionRate: number;
}

export interface PMInsight {
  id: string;
  projectId: string;
  insightType: InsightType;
  title: string;
  description: string;
  impact: InsightImpact;
  metadata: Record<string, unknown>;
  isActive: boolean;
  computedAt: string;
}

// API response types for insights endpoints
export interface ClassificationBreakdownResponse {
  breakdown: Array<{ classification: string; count: number; percentage: number }>;
  total: number;
  flagEnabled: boolean;
}

export interface ImpactAnalysisResponse {
  affectedUsers: number;
  affectedSessions: number;
  occurrenceCount: number;
  firstSeenAt: string;
  lastSeenAt: string;
  rootCause: string | null;
  enhancedClassification: EnhancedClassification | null;
  enhancedSeverity: EnhancedSeverity | null;
  flagEnabled: boolean;
}

export interface BlockedGoalsResponse {
  goals: Array<{ goalType: string; count: number; affectedUsers: number }>;
  total: number;
  flagEnabled: boolean;
}

export interface ErrorTrendsResponse {
  timeSeries: Array<{
    date: string;
    occurrences: number;
    affectedUsers: number;
    affectedSessions: number;
  }>;
  flagEnabled: boolean;
}

export interface FailedActionsResponse {
  actions: Array<{
    action: string;
    errorCount: number;
    totalOccurrences: number;
    affectedUsers: number;
  }>;
  flagEnabled: boolean;
}

export interface FunnelsResponse {
  funnels: FunnelResult[];
  flagEnabled: boolean;
}

export interface PMInsightsResponse {
  insights: Array<{
    insightType: string;
    title: string;
    description: string;
    impact: InsightImpact;
    metadata: Record<string, unknown>;
  }>;
  flagEnabled: boolean;
}

export interface UserErrorDistributionResponse {
  distribution: {
    userErrors: { count: number; percentage: number };
    validationErrors: { count: number; percentage: number };
    systemErrors: { count: number; percentage: number };
    infrastructureErrors: { count: number; percentage: number };
  };
  total: number;
  flagEnabled: boolean;
}

// ---- Health ----

export interface HealthMetrics {
  id: string;
  projectId: string;
  environment: Environment | null;
  healthScore: number;
  errorRate: number;
  crashRate: number;
  apiSuccessRate: number;
  sessionSuccessRate: number;
  activeUsers: number;
  totalEvents: number;
  totalErrors: number;
  periodStart: string;
  periodEnd: string;
  createdAt: string;
}

export interface HealthSummary {
  current: HealthMetrics;
  previous: HealthMetrics | null;
  trend: 'improving' | 'stable' | 'degrading';
  alerts: HealthAlert[];
}

export interface HealthAlert {
  type: NotificationType;
  message: string;
  severity: ErrorSeverity;
  timestamp: string;
}

// ---- Replay ----

export interface ReplayEvent {
  id: string;
  projectId: string;
  sessionId: string;
  eventType: string;
  data: Record<string, unknown>;
  timestamp: string;
}

// ---- Notification ----

export interface Notification {
  id: string;
  projectId: string | null;
  organizationId: string;
  type: NotificationType;
  title: string;
  message: string;
  metadata: Record<string, unknown>;
  isRead: boolean;
  deliveredVia: string[];
  createdAt: string;
}

export interface NotificationSettings {
  id: string;
  projectId: string;
  userId: string;
  emailNotifications: boolean;
  errorSpike: boolean;
  newCriticalError: boolean;
  crashRateIncrease: boolean;
  apiFailureIncrease: boolean;
  healthScoreDrop: boolean;
  sdkOffline: boolean;
}

// ---- User Journey ----

export interface JourneyStep {
  eventName: string;
  eventType: string;
  url: string | null;
  path: string | null;
  timestamp: string;
  properties: EventProperties;
}

export interface UserJourney {
  sessionId: string;
  userId: string | null;
  anonymousId: string | null;
  startedAt: string;
  endedAt: string | null;
  steps: JourneyStep[];
  errorCount: number;
  pageCount: number;
}

// ---- Audit Log ----

export interface AuditLog {
  id: string;
  organizationId: string | null;
  userId: string | null;
  action: string;
  resourceType: string | null;
  resourceId: string | null;
  metadata: Record<string, unknown>;
  ipAddress: string | null;
  createdAt: string;
}

// ---- SDK Ingestion Payloads ----

export interface IngestEventPayload {
  sessionId?: string;
  eventName: string;
  eventType?: string;
  userId?: string;
  anonymousId?: string;
  properties?: EventProperties;
  timestamp?: string;
  url?: string;
  path?: string;
  referrer?: string;
  // TL-OBS V2 optional fields (ignored by V1 SDK consumers)
  goal?: string;
  action?: string;
  // V3C — SDK-declared event domain. When set the ingest route skips
  // server-side name-based classification and uses this value directly,
  // so any eventName works without being in the known-name whitelist.
  eventDomain?: EventDomain;
  // Idempotency key — UUID generated by the SDK per event to deduplicate
  // retried/beaconed events that may be ingested twice on page unload.
  clientEventId?: string;
  // ── Event Envelope V1 SDK metadata (EVT-STAB-201) ──
  // Optional so every existing SDK payload remains valid; SDKs >= the
  // envelope release send all three. Server-derived fields (projectId,
  // environment) are deliberately NOT part of the wire payload.
  schemaVersion?: string;
  sdkName?: string;
  sdkVersion?: string;
  // ── Action Identity Contract v1 (EVT-ACT-201 / EVT-DEC-017) ──
  // Distinct from the legacy TL-OBS `action` string above. Optional; only
  // interaction events carry them. actionLabel is NOT wire-level — it
  // travels inside masked properties (presentation data only).
  actionName?: string;
  actionSource?: ActionSource;
  targetType?: string;
  targetId?: string;
  interactionContractVersion?: string;
}

export interface IngestErrorPayload {
  sessionId?: string;
  errorType?: string;
  message: string;
  stackTrace?: string;
  userId?: string;
  anonymousId?: string;
  url?: string;
  path?: string;
  endpoint?: string;
  requestDurationMs?: number;
  responseCode?: number;
  responseMessage?: string;
  networkStatus?: NetworkStatus;
  appVersion?: string;
  previousEvents?: EventProperties[];
  previousPages?: string[];
  context?: {
    browser?: string;
    browserVersion?: string;
    os?: string;
    osVersion?: string;
    deviceType?: DeviceType;
    deviceModel?: string;
    screenWidth?: number;
    screenHeight?: number;
    networkType?: string;
  };
  // TL-OBS V2 optional fields (ignored by V1 SDK consumers)
  goal?: string;
  action?: string;
  sdkVersion?: string;
}

export interface IngestSessionStartPayload {
  sessionId: string;
  userId?: string;
  anonymousId?: string;
  platform: Platform;
  browser?: string;
  browserVersion?: string;
  os?: string;
  osVersion?: string;
  deviceType?: DeviceType;
  deviceModel?: string;
  screenWidth?: number;
  screenHeight?: number;
  appVersion?: string;
  networkType?: string;
  userAgent?: string;
  // V3B — Visitor Attribution (Wave 2)
  referrer?: string;
  utmSource?: string;
  utmMedium?: string;
  utmCampaign?: string;
  utmContent?: string;
  utmTerm?: string;
  trafficSource?: string;
  landingPage?: string;
  landingUrl?: string;
}

export interface IngestSessionEndPayload {
  sessionId: string;
  durationMs?: number;
  pageCount?: number;
  eventCount?: number;
  errorCount?: number;
}

export interface IngestReplayPayload {
  sessionId: string;
  events: Array<{
    type: number;
    data: Record<string, unknown>;
    timestamp: number;
  }>;
}

// ---- API Response Wrappers ----

export interface ApiResponse<T> {
  success: true;
  data: T;
  message?: string;
}

export interface ApiErrorResponse {
  success: false;
  error: string;
  message: string;
  statusCode: number;
  details?: Record<string, string[]>;
}

export interface PaginatedResponse<T> {
  success: true;
  data: T[];
  pagination: {
    total: number;
    page: number;
    pageSize: number;
    totalPages: number;
  };
}

// ---- Dashboard Analytics ----

export interface EventsAnalytics {
  // Primary metrics
  totalEvents: number;
  previousTotalEvents: number;
  uniqueUsers: number;
  previousUniqueUsers: number;
  activitiesToday: number;
  activitiesTodayByName: Array<{ name: string; count: number }>;

  // Stacked time series — keys are raw eventName strings (top-7) + 'other' catch-all
  stackedTimeSeries: Array<Record<string, string | number>>;
  eventNames: string[];
  granularity: 'hourly' | 'daily' | 'weekly';

  // Legacy row-cap flag (EVT-STAB-501): analytics are now computed by SQL
  // aggregation with no row cap, so this is always false. Kept optional for
  // response-shape compatibility; the portal no longer reads it.
  isCapped?: boolean;

  // Fastest-growing activity across ALL names with previousCount >= 10
  // (EVT-STAB-506). EVT-ACT-101: discriminated selection — only positive
  // growth or a genuinely new activity can be shown; empty states are
  // explicit ('no_growing_events' vs 'not_enough_data').
  fastestGrowing:
    | { kind: 'growth'; name: string; count: number; previousCount: number; growthPct: number }
    | { kind: 'new'; name: string; count: number }
    | { kind: 'none'; reason: 'no_growing_events' | 'not_enough_data' };

  // EVT-ACT-902: the chart's 'other' bucket is inspectable — exact
  // composition (deterministic: everything past the top-7 slice, sorted).
  otherActivities: {
    count: number;
    distinctEvents: number;
    composition: Array<{ name: string; count: number; uniqueVisitors: number }>;
    compositionTruncated: boolean;
  } | null;

  // Minutes WEST of UTC actually applied to bucket/"today" boundaries
  // (EVT-STAB-503). 0 means UTC — either the caller's real zone or the
  // fallback when no tz was sent.
  appliedTzOffsetMinutes: number;

  // Scope actually applied to EVERY metric in this response (EVT-STAB-502,
  // decision EVT-DEC-006). Defaults to 'business' server-side.
  appliedScope: 'all' | 'business' | 'telemetry';

  // Top activities table
  topActivities: Array<{
    name: string;
    count: number;
    uniqueVisitors: number;
    percentage: number;
    previousCount: number;
  }>;

  // Legacy (backward compat)
  topEvents: Array<{ name: string; count: number; percentage: number }>;
  eventTimeSeries: Array<{ date: string; count: number }>;
}

export interface SessionsAnalytics {
  totalSessions: number;
  activeSessions: number;
  avgDurationMs: number;
  avgPageCount: number;
  bounceRate: number;
  sessionTimeSeries: Array<{ date: string; count: number }>;
  deviceBreakdown: Array<{ device: string; count: number; percentage: number }>;
  browserBreakdown: Array<{ browser: string; count: number; percentage: number }>;
  countryBreakdown: Array<{ country: string; count: number }>;
}

export interface ErrorsAnalytics {
  totalErrors: number;
  newErrors: number;
  resolvedErrors: number;
  criticalErrors: number;
  errorRate: number;
  classificationBreakdown: Array<{ classification: string; count: number }>;
  errorTimeSeries: Array<{ date: string; count: number }>;
  topErrors: CapturedError[];
}

// ---- TL-V2-P1: Telemetry Coverage Scoring ----

export type CapabilityKey =
  | 'page_views'
  | 'js_errors'
  | 'session_tracking'
  | 'click_tracking'
  | 'form_events'
  | 'api_monitoring'
  | 'error_classification'
  | 'user_identification'
  | 'rage_click_detection'
  | 'dead_click_detection'
  | 'navigation_loops'
  | 'journey_tracking'
  | 'intent_mapping'
  | 'deployment_events'
  | 'custom_business_events';

export type UpgradeMethod =
  | 'sdk_v2'
  | 'sdk_v2_or_config'
  | 'config'
  | 'cicd_webhook'
  | 'identify_call';
export type CoverageTier = 'basic' | 'advanced' | 'complete';

export interface MissingCapability {
  capability: CapabilityKey;
  upgrade: UpgradeMethod;
  description: string;
}

export interface CoverageResponse {
  score: number;
  tier: CoverageTier;
  implemented: CapabilityKey[];
  missing: MissingCapability[];
  potential: 100;
  flagEnabled: boolean;
}

export interface SdkUpgradeRecommendationResponse {
  currentVersion: string | null;
  latestVersion: string;
  urgency: 'high' | 'medium' | 'low' | 'not_needed';
  lockedCapabilities: Array<{
    capability: CapabilityKey;
    evidenceCount: number | null;
    evidenceDescription: string;
  }>;
  upgradeEstimateMinutes: number;
  breakingChanges: false;
  flagEnabled: boolean;
}

// ---- TL-V2-P1.5: Intent Intelligence ----

export type IntentCategory =
  | 'authentication'
  | 'onboarding'
  | 'purchase'
  | 'payment'
  | 'transfer'
  | 'search'
  | 'navigation'
  | 'configuration'
  | 'support'
  | 'data_export'
  | 'content_creation'
  | 'custom';

export type IntentConfidence = 'high' | 'medium' | 'low';

export type IntentInferredBy =
  | 'explicit'
  | 'config'
  | 'keyword_exact'
  | 'keyword_prefix'
  | 'keyword_substring'
  | 'path';

export interface IntentResult {
  intent: IntentCategory | null;
  confidence: IntentConfidence | null;
  inferredBy: IntentInferredBy | null;
  label: string | null;
}

export interface IntentGoalConfigEntry {
  id: string;
  eventName: string;
  intent: IntentCategory | string;
  label: string | null;
  enabled: boolean;
  createdAt: string;
}

export interface IntentBreakdownItem {
  intent: IntentCategory;
  count: number;
  percentage: number;
  confidenceBreakdown: {
    high: number;
    medium: number;
    low: number;
  };
}

export interface IntentSummaryResponse {
  classifiedEvents: number;
  unclassifiedEvents: number;
  totalEvents: number;
  intentCoverage: number;
  breakdown: IntentBreakdownItem[];
  flagEnabled: boolean;
}

export interface IntentEventItem {
  id: string;
  eventName: string;
  eventType: string | null;
  userId: string | null;
  anonymousId: string | null;
  sessionId: string | null;
  timestamp: string;
  environment: string | null;
  intent: IntentCategory | null;
  confidence: IntentConfidence | null;
  inferredBy: IntentInferredBy | null;
  label: string | null;
}

export interface IntentEventsResponse {
  events: IntentEventItem[];
  nextCursor: string | null;
  flagEnabled: boolean;
}

export interface IntentConfigResponse {
  configs: IntentGoalConfigEntry[];
  flagEnabled: boolean;
}

// ---- TL-V2-P2: Journey Intelligence ----

export type JourneyOutcome = 'success' | 'failure' | 'abandonment';

export interface IntentPhase {
  intent: IntentCategory;
  eventCount: number;
  startedAt: string;
  endedAt: string;
}

export interface IntentProgression {
  phases: IntentPhase[];
  intentArc: IntentCategory[];
  transitionCount: number;
}

// ---- Friction Analytics (TL-V2-P3) ----

export type FrictionPattern = 'repeated_action' | 'error_during_goal' | 'navigation_thrash';
export type FrictionSeverity = 'warning' | 'error' | 'critical';
export type FrictionLevel = 'none' | 'low' | 'medium' | 'high';

// ---- Root Cause Analysis (TL-V2-P4) ----

export type RootCauseCategory =
  | 'authentication_failure'
  | 'validation_failure'
  | 'api_failure'
  | 'network_failure'
  | 'permission_denied'
  | 'dependency_failure'
  | 'configuration_issue'
  | 'frontend_exception'
  | 'rate_limit'
  | 'timeout'
  | 'unknown';

export type RootCauseConfidence = 'low' | 'medium' | 'high';
export type RootCauseImpactLevel = 'low' | 'medium' | 'high' | 'critical';

export interface RootCauseEvidence {
  frictionPattern: FrictionPattern;
  affectedIntent: IntentCategory;
  errorCount: number;
  errorTypes: string[];
  triggeringSignals: string[];
}

export interface RootCause {
  category: RootCauseCategory;
  confidence: RootCauseConfidence;
  impactLevel: RootCauseImpactLevel;
  recommendedAction: string;
  evidence: RootCauseEvidence;
  label: string;
  description: string;
}

export interface RootCauseSummaryResponse {
  totalSessionsAnalyzed: number;
  sessionsWithRootCause: number;
  rootCauseRate: number;
  rootCauseFrequency: Partial<Record<RootCauseCategory, number>>;
  confidenceDistribution: { high: number; medium: number; low: number };
  topCategory: RootCauseCategory | null;
  flagEnabled: boolean;
}

export interface RootCauseSessionResponse {
  sessionId: string;
  frictionSignals: FrictionSignal[];
  primaryRootCause: RootCause | null;
  flagEnabled: boolean;
}

export interface RootCausePatternsResponse {
  patterns: Array<{
    pattern: FrictionPattern;
    intent: IntentCategory;
    category: RootCauseCategory;
    confidence: RootCauseConfidence;
    sessionCount: number;
  }>;
  flagEnabled: boolean;
}

export interface FrictionSignal {
  pattern: FrictionPattern;
  severity: FrictionSeverity;
  affectedIntent: IntentCategory;
  eventName?: string;
  count?: number;
  ratio?: number;
  evidence: string;
  rootCauseCandidate: RootCause | null;
  label: string;
}

export interface FrictionTopPattern {
  pattern: FrictionPattern;
  sessionCount: number;
  percentage: number;
  avgSeverity: FrictionSeverity;
  dominantAffectedIntent: IntentCategory | null;
}

export interface FrictionPatternAnalysis {
  pattern: FrictionPattern;
  sessionCount: number;
  percentage: number;
  avgSeverity: FrictionSeverity;
  severityDistribution: { warning: number; error: number; critical: number };
  topAffectedIntents: IntentCategory[];
  avgFrictionScore: number;
}

export interface FrictionSummaryResponse {
  totalSessionsAnalyzed: number;
  sessionsWithFriction: number;
  frictionRate: number;
  frictionDensity: number;
  avgFrictionScore: number;
  topPatterns: FrictionTopPattern[];
  flagEnabled: boolean;
}

export interface FrictionSessionResponse {
  frictionSignals: FrictionSignal[];
  frictionScore: number;
  frictionLevel: FrictionLevel;
  flagEnabled: boolean;
}

export interface FrictionPatternsResponse {
  patterns: FrictionPatternAnalysis[];
  totalSessionsAnalyzed: number;
  sessionsWithFriction: number;
  flagEnabled: boolean;
}

// ---- Journey Intelligence (TL-V2-P2) — continued ----

export interface JourneyResult {
  sessionId: string;
  dominantIntent: IntentCategory | null;
  terminalIntent: IntentCategory | null;
  outcome: JourneyOutcome;
  journeyHealthScore: number;
  intentProgression: IntentProgression;
  intentsPresent: IntentCategory[];
  navigationRatio: number;
  frictionSignals: FrictionSignal[];
  frictionScore: number;
  frictionLevel: FrictionLevel;
  replayAvailable: boolean;
  flagEnabled: boolean;
}

export interface SessionIntentDistribution {
  intent: IntentCategory;
  sessionCount: number;
  percentage: number;
  avgHealthScore: number;
  successRate: number;
}

export interface JourneyOutcomeStats {
  outcome: JourneyOutcome;
  count: number;
  percentage: number;
  avgHealthScore: number;
  avgDurationMs: number;
}

export interface JourneyPatternEntry {
  arc: IntentCategory[];
  sessionCount: number;
  percentage: number;
  avgHealthScore: number;
  successRate: number;
}

export interface JourneyFunnelStep {
  intent: IntentCategory;
  sessionCount: number;
  conversionRate: number;
  dropoffRate: number;
  avgHealthScore: number;
}

export interface JourneySummaryResponse {
  totalSessionsAnalyzed: number;
  outcomes: JourneyOutcomeStats[];
  intentDistribution: SessionIntentDistribution[];
  avgHealthScore: number;
  flagEnabled: boolean;
}

export interface JourneySessionResponse {
  journey: JourneyResult | null;
  flagEnabled: boolean;
  frictionFlagEnabled: boolean;
}

export interface JourneyPatternsResponse {
  patterns: JourneyPatternEntry[];
  totalSessionsAnalyzed: number;
  flagEnabled: boolean;
}

export interface JourneyFunnelResponse {
  entryIntent: IntentCategory;
  steps: JourneyFunnelStep[];
  totalEntrySessions: number;
  flagEnabled: boolean;
}

export interface JourneyOutcomesResponse {
  outcomes: JourneyOutcomeStats[];
  totalSessions: number;
  avgHealthScore: number;
  flagEnabled: boolean;
}

// ---- Business Impact Analysis (TL-V2-P5) ----

export type ImpactCategory =
  | 'conversion_impact'
  | 'transaction_impact'
  | 'retention_impact'
  | 'onboarding_impact'
  | 'engagement_impact'
  | 'revenue_impact';

export type ImpactTrend = 'improving' | 'stable' | 'worsening';
export type PriorityMovement = 'up' | 'down' | 'unchanged';
export type BusinessRisk = 'low' | 'medium' | 'high' | 'critical';

export interface BusinessImpactIssue {
  issueKey: string;
  rank: number;
  priorityLabel: 'P0' | 'P1' | 'P2' | 'P3';
  impactScore: number;
  impactLabel: 'Critical' | 'High' | 'Medium' | 'Low';
  impactCategory: ImpactCategory;
  isRevenueImpact: boolean;
  businessRisk: BusinessRisk;
  rootCauseCategory: RootCauseCategory;
  rootCauseLabel: string;
  rootCauseImpactLevel: RootCauseImpactLevel;
  rootCauseConfidence: RootCauseConfidence;
  affectedUsers: number;
  hasAnonymousSessions: boolean;
  affectedSessions: number;
  conversionLossRate: number | null;
  baselineConversionRate: number | null;
  confidence: 'high' | 'medium' | 'low';
  confidenceReason: string;
  recommendedAction: string;
  lastSeenAt: string;
  frictionPatterns: FrictionPattern[];
  impactTrend: ImpactTrend;
  priorityMovement: PriorityMovement;
  affectedIntentBreakdown: Partial<Record<IntentCategory, number>>;
}

export interface BusinessImpactSummaryResponse {
  flagEnabled: boolean;
  totalIssues: number;
  criticalIssues: number;
  highIssues: number;
  totalAffectedUsers: number;
  totalAffectedSessions: number;
  topIssue: BusinessImpactIssue | null;
  impactCategoryBreakdown: Partial<Record<ImpactCategory, number>>;
  affectedIntentBreakdown: Partial<Record<IntentCategory, number>>;
}

export interface BusinessImpactIssuesResponse {
  flagEnabled: boolean;
  issues: BusinessImpactIssue[];
}

export interface BusinessImpactIssueDetailResponse {
  flagEnabled: boolean;
  issue: BusinessImpactIssue;
  affectedSessionIds: string[];
  trendByDay: Array<{
    date: string;
    affectedSessions: number;
    affectedUsers: number;
  }>;
}

// ── TL-V2-P6 — Replay Intelligence ──────────────────────────────────────────

export type ReplayAnnotationType =
  | 'error'
  | 'friction'
  | 'root_cause'
  | 'outcome'
  | 'intent_shift'
  | 'business_impact';

export type ReplayAnnotationSeverity = 'info' | 'warning' | 'error' | 'critical';
export type ReplayBusinessRisk = 'low' | 'medium' | 'high' | 'critical';
export type ReplayPriorityLabel = 'low' | 'medium' | 'high' | 'critical';

export interface ReplayAnnotation {
  type: ReplayAnnotationType;
  timestamp: number;
  offsetMs: number;
  label: string;
  severity: ReplayAnnotationSeverity;
  metadata: {
    pattern?: string;
    rootCauseCategory?: string;
    errorType?: string;
    intent?: string;
    outcome?: string;
  };
}

export interface ReplayIntelligence {
  sessionId: string;
  sessionStart: number;
  sessionEnd: number | null;
  durationMs: number | null;
  annotations: ReplayAnnotation[];
  watchWorthyScore: number;
  watchWorthyReasons: string[];
  businessRisk: ReplayBusinessRisk;
  priorityLabel: ReplayPriorityLabel;
  flagEnabled: boolean;
}

export interface WatchWorthySession {
  sessionId: string;
  userId: string | null;
  hasAnonymousId: boolean;
  startedAt: string;
  durationMs: number | null;
  watchWorthyScore: number;
  reasons: string[];
  frictionLevel: string;
  outcome: string | null;
  errorCount: number;
  deepLink: string;
}

export interface ReplayIntelligenceListResponse {
  sessions: WatchWorthySession[];
  total: number;
  flagEnabled: boolean;
}

// ── TL-V2-P7 — AI Recommendations ───────────────────────────────────────────

export type RecommendationCategory =
  | 'ux_improvement'
  | 'validation_fix'
  | 'api_reliability'
  | 'authentication'
  | 'performance'
  | 'navigation'
  | 'conversion_optimization'
  | 'investigation';

export type RecommendationConfidence = 'high' | 'medium' | 'low';
export type RecommendationPriority = 'critical' | 'high' | 'medium' | 'low';
export type ExpectedOutcome =
  | 'conversion_improvement'
  | 'error_reduction'
  | 'engagement_improvement'
  | 'performance_improvement'
  | 'retention_improvement';
export type RecommendationStatus = 'new' | 'reviewing' | 'accepted' | 'dismissed';

export interface RecommendationEvidence {
  signalType: 'friction' | 'root_cause' | 'business_impact' | 'journey_outcome' | 'replay';
  label: string;
  value: string | number;
  weight: 'primary' | 'supporting';
}

export interface RecommendationDeepLink {
  label: string;
  path: string;
}

export interface Recommendation {
  id: string;
  category: RecommendationCategory;
  title: string;
  description: string;
  reasoning: string;
  whyThisMatters: string;
  evidence: RecommendationEvidence[];
  confidence: RecommendationConfidence;
  confidenceReason: string;
  priority: RecommendationPriority;
  affectedIntent: string | null;
  sessionsAffected: number;
  usersAffected: number;
  signalCount: number;
  sourceTrace: string[];
  deepLinks: RecommendationDeepLink[];
  expectedImpact: {
    usersPotentiallyRecovered: number | null;
    conversionPotentialGain: number | null;
  };
  expectedOutcome: ExpectedOutcome;
  readinessScore: number;
  recommendationVersion: string;
  status?: RecommendationStatus;
  flagEnabled: boolean;
}

export interface RecommendationSummary {
  totalRecommendations: number;
  highConfidence: number;
  criticalCount: number;
  byCategory: Partial<Record<RecommendationCategory, number>>;
  flagEnabled: boolean;
}

export interface RecommendationListResponse {
  recommendations: Recommendation[];
  summary: RecommendationSummary;
  flagEnabled: boolean;
}

// ── V3B — Visitor Intelligence (Wave 4B / Wave 5) ────────────────────────────

export interface VisitorListItem {
  visitorId: string;
  userId: string | null;
  firstSeenAt: string;
  lastSeenAt: string;
  sessionCount: number;
  eventCount: number;
  errorCount: number;
  firstTouchSource: string | null;
  firstTouchMedium: string | null;
  firstTouchCampaign: string | null;
  referringDomain: string | null;
}

export interface VisitorDetail {
  visitorId: string;
  userId: string | null;
  firstSeenAt: string;
  lastSeenAt: string;
  sessionCount: number;
  eventCount: number;
  errorCount: number;
  conversionCount: number;
  firstTouchSource: string | null;
  firstTouchMedium: string | null;
  firstTouchCampaign: string | null;
  referringDomain: string | null;
}

export interface VisitorAttribution {
  firstTouchSource: string | null;
  firstTouchMedium: string | null;
  firstTouchCampaign: string | null;
  referringDomain: string | null;
  firstSeenAt: string;
}

export interface VisitorMetrics {
  sessionCount: number;
  eventCount: number;
  errorCount: number;
  conversionCount: number;
  countersReliable: boolean;
  firstSeenAt: string;
  lastSeenAt: string;
}

export interface VisitorSession {
  sessionId: string;
  startedAt: string;
  endedAt: string | null;
  durationMs: number | null;
  trafficSource: string | null;
  landingPage: string | null;
  landingUrl: string | null;
  referringDomain: string | null;
  referrer: string | null;
  isNewVisitor: boolean | null;
  platform: string;
  browser: string | null;
  deviceType: string | null;
  country: string | null;
  pageCount: number;
  eventCount: number;
  errorCount: number;
  environment: string | null;
}

export type TimelineItemType = 'session_start' | 'event' | 'error';

export interface TimelineItem {
  type: TimelineItemType;
  timestamp: string;
  sessionId: string | null;
  eventName?: string;
  eventType?: string;
  path?: string;
  url?: string;
  errorType?: string;
  message?: string;
  severity?: string;
}

export interface VisitorProfileResponse {
  visitor: VisitorDetail;
  attribution: VisitorAttribution | null;
  metrics: VisitorMetrics | null;
  recentSessions: VisitorSession[];
}

export interface VisitorOverview {
  totalVisitors: number;
  newVisitors: number;
  returningVisitors: number;
  averageSessionsPerVisitor: number;
}

export interface VisitorSourceItem {
  source: string;
  visitorCount: number;
  percentage: number;
}

export interface VisitorReferrerItem {
  domain: string;
  visitorCount: number;
}

export interface VisitorLandingPageItem {
  landingPage: string;
  visitorCount: number;
}

export interface VisitorCampaignItem {
  utmCampaign: string;
  visitorCount: number;
}

export interface NewVsReturningDay {
  date: string;
  newVisitors: number;
  returningVisitors: number;
  totalVisitors: number;
}

export interface NewVsReturningResult {
  days: NewVsReturningDay[];
  totalNew: number;
  totalReturning: number;
  totalVisitors: number;
}

export interface VisitorPagination {
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

export interface VisitorListResponse {
  data: VisitorListItem[];
  pagination: VisitorPagination;
}

export interface VisitorSessionsResponse {
  data: VisitorSession[];
  pagination: VisitorPagination;
}
