/**
 * Central sensitive-property policy (EVT-STAB-401).
 *
 * THE single source of truth for which property keys are masked before
 * storage. The audit found FOUR independently-maintained regex sets (web
 * SDK, React Native SDK, Flutter SDK, server) that had all drifted — with
 * real consequences (RN's unbounded `pin` masked "spinner"; only the server
 * had `\bkey\b`; none had email until the Sprint 1 hotfix).
 *
 * Consumers:
 *   - apps/api/src/utils/mask.ts               (imports the compiled regexes)
 *   - packages/sdk/web/src/utils/mask.ts        (imports the compiled regexes)
 *   - packages/sdk/react-native/src/utils/mask.ts (imports the compiled regexes)
 *   - packages/sdk/flutter/lib/src/mask.dart     (CANNOT import TypeScript —
 *     carries a hand-synced copy of the alternations below, enforced by
 *     apps/api/src/__tests__/masking-policy-sync.test.ts which reads the
 *     Dart source and fails CI on drift)
 *
 * Two independent categories:
 *   CREDENTIALS — always masked, everywhere, no exceptions.
 *   PII — masked in ordinary event properties, EXEMPT in identify traits
 *   (email/phone are canonical identity traits; see EVT-STAB-401 Sprint 1).
 *
 * Pattern style: lower-noise word boundaries where a term is a common
 * substring of harmless words (pin/spinner, auth/author, card/cardigan,
 * bank/embankment, key/monkey); bare substrings where the term is already
 * specific (password, secret, cookie, authorization).
 */

/** Regex sources — kept as strings so the Dart sync test can compare them. */
export const CREDENTIAL_KEY_PATTERN_SOURCES: readonly string[] = [
  'password',
  'passwd',
  'passcode',
  '\\bpin\\b',
  '\\botp\\b',
  '\\btoken\\b',
  'accesstoken',
  'access_?token',
  'authtoken',
  'auth_?token',
  'refresh_?token',
  '\\bauth\\b',
  'authorization',
  'secret',
  'cookie',
  'apikey',
  'api_key',
  '\\bkey\\b',
  '\\bcard\\b',
  'cardnumber',
  'card_number',
  'credit_card',
  'creditcard',
  'debit_card',
  'debitcard',
  '\\bcvv\\b',
  '\\bbank\\b',
  'account_?number',
  'accountnumber',
  '\\bssn\\b',
  'social_security',
];

/** PII sources — masked in event properties, exempt in identify traits. */
export const PII_KEY_PATTERN_SOURCES: readonly string[] = ['email', 'phone'];

const credentialRegexes = CREDENTIAL_KEY_PATTERN_SOURCES.map((s) => new RegExp(s, 'i'));
const piiRegexes = PII_KEY_PATTERN_SOURCES.map((s) => new RegExp(s, 'i'));

/** True when a property key must ALWAYS be masked (credential material). */
export function isCredentialKey(key: string): boolean {
  return credentialRegexes.some((re) => re.test(key));
}

/** True when a property key is PII (masked in events, exempt in identify traits). */
export function isPiiPropertyKey(key: string): boolean {
  return piiRegexes.some((re) => re.test(key));
}
