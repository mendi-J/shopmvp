// ============================================================
// Action Identity Contract v1 (EVT-ACT-201 / EVT-DEC-017)
// ============================================================
// Shared, dependency-free implementation of the normalization, privacy,
// and stability rules in infrastructure/event-action-identity-contract.md.
// Same types-only-exception rationale as the event registry and masking
// policy: the Web SDK resolves identity with these rules at capture time
// and the API re-validates with the SAME rules at ingest — one source, no
// per-consumer drift.

import { isCredentialKey, isPiiPropertyKey } from './masking-policy';

/** Bumped only on MATERIAL changes to resolution/normalization (contract §6). */
export const INTERACTION_CONTRACT_VERSION = '1';

export const ACTION_SOURCES = [
  'DECLARED',
  'APPLICATION_METADATA',
  'ACCESSIBILITY_METADATA',
  'VISIBLE_LABEL',
  'CONTEXT_FALLBACK',
  'UNIDENTIFIED',
] as const;
export type ActionSource = (typeof ACTION_SOURCES)[number];

export const ACTION_IDENTITY_LIMITS = {
  actionName: 64,
  actionLabel: 120,
  targetType: 32,
  targetId: 64,
  contractVersion: 8,
  /** Visible text longer than this is a sentence, not a label (contract §4.3). */
  visibleLabelMax: 60,
} as const;

/** Aggregation-layer reserved names (contract §2) — never a resolved actionName. */
export const RESERVED_ACTION_NAMES = [
  'unidentified_interaction',
  'other_actions',
  'other_targets',
  'other_operations',
] as const;

/** Action identity fields as they travel on the wire and into Event columns. */
export interface ActionIdentityFields {
  actionName?: string;
  actionSource?: ActionSource;
  targetType?: string;
  targetId?: string;
  interactionContractVersion?: string;
}

const EMAIL_TOKEN = /[^\s@]+@[^\s@]+\.[^\s@]+/;
const UUID_LIKE = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i;
const HEX_RUN = /[0-9a-f]{8,}/i;
const DIGIT_RUN_4 = /\d{4,}/;
/** Framework-generated id prefixes that are unstable across builds/renders. */
const GENERATED_ID_PREFIXES = /^(radix-|headlessui-|mui-|:r|ember\d|svelte-|ng-)/i;

function digitRatio(value: string): number {
  if (!value.length) return 0;
  const digits = value.replace(/\D/g, '').length;
  return digits / value.length;
}

/**
 * Privacy gate (contract §4.2): a candidate label/name/target value is
 * unsafe when it looks like a credential/PII key, contains an email-shaped
 * token, or is digit-heavy. Unsafe candidates are REJECTED (the tier falls
 * through) — never masked-and-kept, because a masked action name is useless
 * as identity.
 */
export function isSafeActionValue(value: string): boolean {
  if (!value) return false;
  if (EMAIL_TOKEN.test(value)) return false;
  if (digitRatio(value) >= 0.5) return false;
  if (isCredentialKey(value) || isPiiPropertyKey(value)) return false;
  return true;
}

/**
 * Target-id gate (contract §4.4): targetId is explicitly DECLARED and
 * drill-down-bounded, so digits are legitimate (product ids, row ids) —
 * unlike labels/names. Still rejected: email-shaped values, credential/PII
 * key patterns, and account/card-shaped values (7+ consecutive digits).
 */
export function isSafeTargetId(value: string): boolean {
  if (!value) return false;
  if (EMAIL_TOKEN.test(value)) return false;
  if (/\d{7,}/.test(value)) return false;
  if (isCredentialKey(value) || isPiiPropertyKey(value)) return false;
  return true;
}

/**
 * Stability gate for tier-2 application metadata (contract §4.3): rejects
 * values that look machine-generated and would churn across builds.
 */
export function isStableMetadataValue(value: string): boolean {
  if (!value) return false;
  if (GENERATED_ID_PREFIXES.test(value)) return false;
  if (UUID_LIKE.test(value)) return false;
  if (HEX_RUN.test(value)) return false;
  if (DIGIT_RUN_4.test(value)) return false;
  return true;
}

/**
 * Deterministic actionName normalization (contract §4.1).
 * Returns null when nothing usable remains — callers treat that as tier
 * rejection, not as an empty name.
 */
export function normalizeActionName(raw: string): string | null {
  if (!raw) return null;
  let name = raw.normalize('NFKC').toLowerCase().trim();
  // Runs of whitespace/punctuation → single underscore.
  name = name.replace(/[^a-z0-9]+/g, '_');
  // Digit runs of 3+ chars go — the specific target belongs in targetId.
  name = name.replace(/_?\d{3,}_?/g, '_');
  name = name.replace(/_{2,}/g, '_').replace(/^_+|_+$/g, '');
  if (!name) return null;
  if (name.length > ACTION_IDENTITY_LIMITS.actionName) {
    const cut = name.slice(0, ACTION_IDENTITY_LIMITS.actionName);
    const boundary = cut.lastIndexOf('_');
    name = boundary > 0 ? cut.slice(0, boundary) : cut;
  }
  // Reserved aggregation names are suffix-disambiguated (contract §2).
  if ((RESERVED_ACTION_NAMES as readonly string[]).includes(name)) {
    name = `${name}_declared`;
  }
  return name;
}

/** Wire-shape validity check for a normalized actionName (server re-validation). */
export function isValidNormalizedActionName(value: string): boolean {
  return (
    value.length > 0 &&
    value.length <= ACTION_IDENTITY_LIMITS.actionName &&
    /^[a-z0-9_]+$/.test(value) &&
    !(RESERVED_ACTION_NAMES as readonly string[]).includes(value)
  );
}

export function isActionSource(value: string): value is ActionSource {
  return (ACTION_SOURCES as readonly string[]).includes(value);
}
