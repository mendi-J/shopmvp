# @tracklens/web-sdk

TrackLens Web SDK — browser event tracking, error capture, and session replay.

## Installation

```bash
npm install @tracklens/web-sdk
# or
yarn add @tracklens/web-sdk
# or
pnpm add @tracklens/web-sdk
```

---

## Quick Start (ESM / CJS)

```ts
import TrackLens from '@tracklens/web-sdk';

TrackLens.init({
  apiKey: 'tl_live_prod_xxxxxxxxxxxx',
  environment: 'production',
  enableReplay: true,
  debug: false,
});

// Identify a logged-in user
TrackLens.identify('user_123', { plan: 'pro', email: 'user@example.com' });

// Track a custom event
TrackLens.track('checkout_started', { cartTotal: 49.99, currency: 'USD' });

// Manually capture an error
try {
  riskyOperation();
} catch (err) {
  TrackLens.captureError(err, { context: 'checkout' });
}
```

---

## CDN / Script Tag Usage

Add the pre-load stub **before** the SDK script so calls made before the bundle
loads are queued and replayed:

```html
<!-- 1. Pre-load stub (synchronous, tiny) -->
<script>
  window.tracklensQueue = window.tracklensQueue || [];
  window.TrackLens = {
    track: function () {
      tracklensQueue.push(['track', arguments]);
    },
    identify: function () {
      tracklensQueue.push(['identify', arguments]);
    },
    init: function () {
      tracklensQueue.push(['init', arguments]);
    },
  };
  // Initialize immediately — calls are queued until the SDK loads
  TrackLens.init({ apiKey: 'tl_live_prod_xxxxxxxxxxxx' });
</script>

<!-- 2. Load the SDK bundle asynchronously -->
<script src="https://cdn.tracklens.io/sdk/v1/tracklens.min.js" async></script>
```

---

## React Integration

```tsx
// app/providers.tsx
import { TrackLensProvider } from '@tracklens/web-sdk/react';

export function Providers({ children }: { children: React.ReactNode }) {
  return <TrackLensProvider config={{ apiKey: 'tl_live_prod_...' }}>{children}</TrackLensProvider>;
}
```

```tsx
// components/CheckoutButton.tsx
import { useTrackLens } from '@tracklens/web-sdk/react';

export function CheckoutButton() {
  const { track } = useTrackLens();

  return <button onClick={() => track('checkout_clicked', { plan: 'pro' })}>Upgrade</button>;
}
```

---

## Next.js Integration

```tsx
// app/layout.tsx  (App Router)
import { TrackLensScript } from '@tracklens/web-sdk/nextjs';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <TrackLensScript config={{ apiKey: 'tl_live_prod_...' }} />
        {children}
      </body>
    </html>
  );
}
```

---

## Configuration Reference

| Option                | Type       | Default                    | Description                                                                               |
| --------------------- | ---------- | -------------------------- | ----------------------------------------------------------------------------------------- |
| `apiKey`              | `string`   | **required**               | SDK key from the TrackLens dashboard                                                      |
| `apiUrl`              | `string`   | `https://api.tracklens.io` | Base URL of the ingest API                                                                |
| `environment`         | `string`   | `production`               | Label attached to every event (`development`, `staging`, `production`)                    |
| `autoTrack`           | `boolean`  | `true`                     | Automatically track page views, clicks, form submissions, JS errors, and network failures |
| `enableReplay`        | `boolean`  | `true`                     | Record and stream session replay via rrweb                                                |
| `replayBatchSize`     | `number`   | `50`                       | Number of rrweb events to buffer before flushing                                          |
| `replayFlushInterval` | `number`   | `5000`                     | Milliseconds between automatic replay flushes                                             |
| `maskSelectors`       | `string[]` | `[]`                       | CSS selectors whose content is blocked in replay recordings                               |
| `debug`               | `boolean`  | `false`                    | Print SDK internals to the browser console                                                |
| `appVersion`          | `string`   | `undefined`                | App version forwarded with sessions and errors                                            |

---

## Public API

```ts
TrackLens.init(config)
TrackLens.identify(userId, traits?)
TrackLens.track(eventName, properties?)
TrackLens.captureError(error, context?)
TrackLens.startSession()
TrackLens.endSession()
TrackLens.setUser(userId)
TrackLens.clearUser()
TrackLens.reset()
```

---

## Sensitive Data Masking

All data is masked **client-side** before it leaves the browser.
Property keys matching the following pattern are replaced with `[MASKED]`:

```
password, pin, otp, token, secret, cookie, card, cvv, ban, account, apikey, api_key, auth
```

This applies recursively to nested objects and to form field values captured
by the auto-track plugin.

In session replays, the following elements are automatically blocked:

- `input[type="password"]`
- Inputs whose `name` contains `card`, `cvv`, `pin`, `otp`, `token`, `secret`, `auth`
- Any element with the `data-tracklens-mask` attribute

---

## Vue 3 Integration

```ts
// main.ts
import { createApp } from 'vue';
import { createRouter, createWebHistory } from 'vue-router';
import TrackLensPlugin from '@tracklens/web-sdk/vue';
import App from './App.vue';

const router = createRouter({ history: createWebHistory(), routes });
const app = createApp(App);

app.use(TrackLensPlugin, {
  apiKey: 'tl_live_prod_...',
  router, // enables automatic page-view tracking on every route transition
});

app.use(router).mount('#app');
```

```vue
<script setup lang="ts">
import { useTrackLens } from '@tracklens/web-sdk/vue';

const { track, identify } = useTrackLens();
</script>
```

---

## Angular Integration

```ts
// app.module.ts
import { HttpClientModule } from '@angular/common/http';
import { TrackLensModule } from '@tracklens/web-sdk/angular';

@NgModule({
  imports: [
    HttpClientModule,
    TrackLensModule.forRoot({
      apiKey: 'tl_live_prod_...',
      environment: 'production',
    }),
  ],
})
export class AppModule {}
```

```ts
// my.component.ts
import { TrackLensService } from '@tracklens/web-sdk/angular';

@Component({ ... })
export class MyComponent {
  constructor(private tracklens: TrackLensService) {}

  onAction() {
    this.tracklens.track('cta_clicked', { cta: 'get_started' });
  }
}
```

The `TrackLensHttpInterceptor` is registered automatically by `forRoot()` and
captures all `HttpClient` 4xx/5xx failures as TrackLens error events.

---

## Session Replay

Session replay uses [rrweb](https://github.com/rrweb-io/rrweb) and requires it
as a peer dependency:

```bash
npm install rrweb@^2.0.0-alpha.14
```

Replay is enabled by default. To disable it:

```ts
TrackLens.init({ apiKey: '...', enableReplay: false });
```

To mask additional elements from being recorded, pass CSS selectors:

```ts
TrackLens.init({
  apiKey: '...',
  maskSelectors: ['.credit-card-number', '#ssn-field'],
});
```
